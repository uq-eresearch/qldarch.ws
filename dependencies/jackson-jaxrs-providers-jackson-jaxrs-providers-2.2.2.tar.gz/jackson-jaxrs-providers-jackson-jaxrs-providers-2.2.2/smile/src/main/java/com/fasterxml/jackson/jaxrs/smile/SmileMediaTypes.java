package com.fasterxml.jackson.jaxrs.smile;

import javax.ws.rs.core.MediaType;

public class SmileMediaTypes {

	public static final String    APPLICATION_JACKSON_SMILE      = "application/x-jackson-smile";
	public static final MediaType APPLICATION_JACKSON_SMILE_TYPE = MediaType.valueOf(APPLICATION_JACKSON_SMILE);
}
